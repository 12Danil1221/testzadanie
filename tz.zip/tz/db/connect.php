<?php  
//Подключаемся к БД через класс PDO
$pdo = new PDO ('mysql:host=localhost;dbname=tz;port=3306', 'root', '');

?>