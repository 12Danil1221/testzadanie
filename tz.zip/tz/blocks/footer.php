<style>
footer {
    position: fixed;
    width: 100%;
    background-color: #333333;
    text-decoration: none;
    color: white;
}
</style>
<footer>
    <!-- Подвал наших страниц -->
    <div style="display: flex;">
        <div>
            <span class="logo"></span>
            <p>Lorem Ipsum is simply dummy text of the <br> printing and typesetting industry. </p>
        </div>
        <ul style="width:auto; display:flex; align-items: center;">
            <li>
                <p>2024</p>
            </li>
            <li style="margin-left:20%; width:110px;">О нас</li>
            <li style="margin-left:20%; width:180px;">Где находимся</li>
        </ul>
    </div>

</footer>